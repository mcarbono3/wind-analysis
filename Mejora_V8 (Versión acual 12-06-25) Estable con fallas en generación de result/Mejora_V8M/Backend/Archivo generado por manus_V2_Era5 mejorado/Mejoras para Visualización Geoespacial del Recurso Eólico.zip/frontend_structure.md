# Estructura del Frontend - Wind Analysis

## Archivos principales identificados:

### App.jsx
- Aplicación React principal con 1221 líneas
- Usa react-leaflet para el mapa
- Configuración API: https://wind-analysis.onrender.com/api
- Componentes UI de shadcn/ui
- Librerías de gráficos: recharts
- Exportación: xlsx, jspdf

### Estructura de directorios:
- frontend/src/
  - assets/
  - components/
    - ui/ (componentes shadcn/ui)
  - hooks/
  - lib/
  - App.css
  - App.jsx
  - index.css
  - main.jsx

### Componentes del mapa identificados:
- MapContainer de react-leaflet
- TileLayer
- Rectangle
- useMapEvents
- useMap

## Mejora requerida:
1. Agregar leaflet.heat como dependencia
2. Crear componente HeatmapLayer para mostrar datos de viento promedio
3. Integrar llamada al nuevo endpoint /api/wind-average-10m
4. Mostrar capa de calor al cargar el mapa inicial

