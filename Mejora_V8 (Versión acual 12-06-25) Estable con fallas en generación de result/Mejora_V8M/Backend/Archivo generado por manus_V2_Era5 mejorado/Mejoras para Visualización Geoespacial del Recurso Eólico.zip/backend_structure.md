# Estructura del Backend - Wind Analysis

## Archivos principales identificados:

### main.py
- Aplicación Flask principal
- Configuración CORS para https://mcarbono3.github.io
- Blueprints registrados: user_bp, era5_bp, analysis_bp, ai_bp, export_bp
- Base de datos SQLite configurada

### routes/era5.py
- Blueprint para manejo de datos ERA5
- Endpoint principal: `/api/wind-data` (POST)
- Clase ERA5Service con métodos para validación y generación de datos
- Actualmente en modo test con datos simulados

## Estructura de directorios:
- backend/src/
  - database/
  - models/
  - routes/
    - ai.py
    - analysis.py
    - era5.py
    - export.py
    - user.py
  - services/
  - static/
  - __init__.py
  - main.py

## Mejora requerida:
Agregar nuevo endpoint `/api/wind-average-10m` en era5.py para obtener datos de velocidad promedio del viento a 10m para visualización en mapa inicial.

