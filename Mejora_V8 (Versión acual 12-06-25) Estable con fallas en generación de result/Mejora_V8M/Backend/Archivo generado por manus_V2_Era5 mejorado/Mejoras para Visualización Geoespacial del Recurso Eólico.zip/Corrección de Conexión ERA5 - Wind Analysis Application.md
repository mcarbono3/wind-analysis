# Corrección de Conexión ERA5 - Wind Analysis Application

## Diagnóstico del Problema

Después de revisar el código `era5_improved.py`, identifiqué varios problemas que impedían la conexión exitosa a la API de Copernicus CDS:

### Problemas Identificados:

1. **Inicialización incorrecta del cliente CDS**: El cliente se inicializaba sin pasar explícitamente las credenciales
2. **Test mode activado**: La variable `self.test_mode = True` forzaba el uso de datos simulados
3. **Manejo de credenciales**: No se verificaba correctamente la presencia de las variables de entorno
4. **Falta de logging detallado**: No había suficiente información de depuración para diagnosticar problemas

## Correcciones Implementadas

### 1. Inicialización Correcta del Cliente CDS

**Antes:**
```python
c = cdsapi.Client()
```

**Después:**
```python
# Configurar credenciales de CDS desde variables de entorno
cds_url = os.environ.get("CDSAPI_URL")
cds_key = os.environ.get("CDSAPI_KEY")

if not cds_url or not cds_key:
    raise ValueError("Las variables de entorno CDSAPI_URL o CDSAPI_KEY no están configuradas.")

# Inicializar cliente CDS con credenciales
c = cdsapi.Client(url=cds_url, key=cds_key)
```

### 2. Desactivación del Modo de Prueba

**Antes:**
```python
self.test_mode = True
```

**Después:**
```python
self.test_mode = False  # Cambiado a False para intentar siempre datos reales
```

### 3. Verificación de Credenciales

Se agregó validación explícita de las variables de entorno antes de intentar la conexión:

```python
if not cds_url or not cds_key:
    raise ValueError("Las variables de entorno CDSAPI_URL o CDSAPI_KEY no están configuradas.")
```

### 4. Logging Mejorado

Se agregaron más mensajes de logging para facilitar la depuración:

```python
logger.info(f"🌍 Solicitando datos de ERA5 para región: [{north}, {west}, {south}, {east}]")
logger.info("📡 Descargando componente U del viento...")
logger.info("📡 Descargando componente V del viento...")
logger.info("🔄 Procesando datos con xarray...")
```

## Configuración de Credenciales Verificada

Según la imagen proporcionada, las credenciales en Render están configuradas correctamente:

- **CDSAPI_KEY**: `45cfdc65-53d4-4a5e-91ed-37d24caf9c41`
- **CDSAPI_URL**: `https://cds.climate.copernicus.eu/api/v2`

## Archivos Corregidos

### 1. era5_improved.py (Versión 3.2)

**Ubicación**: `backend/src/routes/era5.py`

**Cambios principales**:
- Cliente CDS inicializado con credenciales explícitas
- Test mode desactivado (`self.test_mode = False`)
- Validación de variables de entorno
- Logging mejorado para depuración
- Manejo robusto de errores

### 2. requirements_updated.txt

**Ubicación**: `backend/requirements.txt`

**Dependencias agregadas**:
```txt
cdsapi>=0.6.1
xarray>=2023.1.0
netcdf4>=1.6.0
python-dotenv
```

### 3. test_cds_connection.py

**Ubicación**: `backend/test_cds_connection.py` (nuevo archivo)

Script de prueba para verificar la conexión a CDS antes del despliegue.

## Instrucciones de Despliegue

### Paso 1: Actualizar el Backend

1. **Reemplazar el archivo era5.py**:
   ```bash
   # Copiar el contenido de era5_improved.py a backend/src/routes/era5.py
   ```

2. **Actualizar requirements.txt**:
   ```bash
   # Agregar las nuevas dependencias al archivo requirements.txt
   ```

3. **Verificar variables de entorno en Render**:
   - ✅ CDSAPI_URL: `https://cds.climate.copernicus.eu/api/v2`
   - ✅ CDSAPI_KEY: `45cfdc65-53d4-4a5e-91ed-37d24caf9c41`

### Paso 2: Probar la Conexión (Opcional)

Antes del despliegue, puedes probar la conexión localmente:

```bash
cd backend
export CDSAPI_URL="https://cds.climate.copernicus.eu/api/v2"
export CDSAPI_KEY="45cfdc65-53d4-4a5e-91ed-37d24caf9c41"
python test_cds_connection.py
```

### Paso 3: Desplegar en Render

```bash
git add backend/src/routes/era5.py
git add backend/requirements.txt
git commit -m "fix: corregir conexión a API de Copernicus CDS para datos reales de ERA5"
git push origin main
```

### Paso 4: Verificar el Funcionamiento

1. **Monitorear logs en Render** para verificar:
   - Inicialización correcta del cliente CDS
   - Descarga exitosa de datos ERA5
   - Procesamiento correcto con xarray

2. **Probar el endpoint**:
   ```bash
   curl https://wind-analysis.onrender.com/api/wind-average-10m
   ```

3. **Verificar en el frontend** que el heatmap muestre datos reales (metadata.data_source = "ERA5_real")

## Diferencias Clave en el Comportamiento

### Antes de la Corrección:
- ❌ Cliente CDS sin credenciales explícitas
- ❌ Test mode activado (siempre datos simulados)
- ❌ Falta de validación de variables de entorno
- ❌ Logging insuficiente para depuración

### Después de la Corrección:
- ✅ Cliente CDS con credenciales explícitas
- ✅ Test mode desactivado (intenta datos reales primero)
- ✅ Validación robusta de variables de entorno
- ✅ Logging detallado para monitoreo
- ✅ Fallback inteligente a datos simulados solo en caso de error

## Monitoreo y Depuración

### Logs Esperados (Éxito):
```
🌬️ === INICIO SOLICITUD WIND-AVERAGE-10M ===
🌍 Solicitando datos de ERA5 para región: [13.0, -77.0, 7.0, -71.0]
📡 Descargando componente U del viento...
📡 Descargando componente V del viento...
🔄 Procesando datos con xarray...
✅ Datos procesados: 500 puntos de viento promedio
✅ Datos de viento promedio generados: 500 puntos (ERA5_real)
```

### Logs Esperados (Fallback):
```
🌬️ === INICIO SOLICITUD WIND-AVERAGE-10M ===
❌ Error obteniendo datos reales de ERA5: [detalle del error]
🎲 Generando datos simulados de viento promedio...
✅ Datos simulados generados: 500 puntos
⚠️ Fallback a datos simulados: [detalle del error]
```

## Solución de Problemas

### Si aún se obtienen datos simulados:

1. **Verificar credenciales en Render**:
   - Confirmar que las variables de entorno están configuradas
   - Verificar que no hay espacios extra en los valores

2. **Revisar logs de Render**:
   - Buscar mensajes de error específicos
   - Verificar que las dependencias se instalaron correctamente

3. **Verificar conectividad**:
   - Confirmar que Render puede acceder a `cds.climate.copernicus.eu`
   - Verificar que no hay restricciones de firewall

4. **Validar credenciales**:
   - Confirmar que el User ID es correcto
   - Verificar que la API key está activa en Copernicus

### Comandos de Depuración:

```bash
# Verificar variables de entorno en Render
echo $CDSAPI_URL
echo $CDSAPI_KEY

# Probar conexión básica
curl -I https://cds.climate.copernicus.eu/api/v2

# Verificar instalación de dependencias
pip list | grep cdsapi
pip list | grep xarray
pip list | grep netcdf4
```

## Próximos Pasos

Una vez implementada esta corrección:

1. **Monitorear el rendimiento**: Los datos reales pueden tardar más en descargarse
2. **Implementar caché**: Considerar almacenar datos descargados para mejorar rendimiento
3. **Optimizar región**: Ajustar el área geográfica si es necesario
4. **Actualizar período**: Considerar usar datos más recientes o múltiples años

---

*Corrección implementada el 15 de junio de 2025*
*Versión: 3.2*
*Estado: Listo para despliegue*

