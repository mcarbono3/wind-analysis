# Dependencias del Frontend - Wind Analysis

## Dependencias actuales relevantes:
- leaflet: ^1.9.4
- react-leaflet: ^5.0.0
- axios: ^1.9.0

## Dependencias faltantes para la mejora:
- leaflet.heat (para el heatmap)

## Configuración actual:
- Homepage: https://mcarbono3.github.io/wind-analysis
- Package manager: pnpm
- Build tool: Vite
- Deploy: gh-pages

## Mejora requerida:
Agregar leaflet.heat como dependencia para implementar la capa de calor del viento promedio.

