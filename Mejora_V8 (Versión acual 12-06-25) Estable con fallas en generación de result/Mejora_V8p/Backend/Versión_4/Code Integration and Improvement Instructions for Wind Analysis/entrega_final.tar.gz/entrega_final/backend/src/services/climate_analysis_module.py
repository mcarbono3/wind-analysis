import pandas as pd
from geopy.distance import geodesic
import joblib
import os

class ClimateAnalysisModule:
    def __init__(self, hurdat_data_path, model_path):
        self.hurdat_data_path = hurdat_data_path
        self.model_path = model_path
        self.hurdat_df = self._load_hurdat_data()
        self.model = self._load_model()

        # Define Colombian Caribbean bounding box (approximate)
        self.caribbean_bbox = {
            "min_lat": 10.0,
            "max_lat": 13.0,
            "min_lon": -82.0,
            "max_lon": -74.0
        }

    def _load_hurdat_data(self):
        if not os.path.exists(self.hurdat_data_path):
            raise FileNotFoundError(f"HURDAT data file not found at {self.hurdat_data_path}")
        # Ensure date and time are read as strings
        return pd.read_csv(self.hurdat_data_path, dtype={
            "date": str,
            "time": str
        })

    def _load_model(self):
        if not os.path.exists(self.model_path):
            raise FileNotFoundError(f"Model file not found at {self.model_path}")
        return joblib.load(self.model_path)

    def _calculate_metrics(self, df, analysis_point_lat, analysis_point_lon, radius_km=200):
        # Filter events within the Caribbean bounding box
        caribbean_events = df[
            (df["latitude_float"] >= self.caribbean_bbox["min_lat"])
            & (df["latitude_float"] <= self.caribbean_bbox["max_lat"])
            & (df["longitude_float"] >= self.caribbean_bbox["min_lon"])
            & (df["longitude_float"] <= self.caribbean_bbox["max_lon"])
        ].copy()

        if caribbean_events.empty:
            return {
                "event_density": 0,
                "event_frequency": {},
                "event_intensity_profile": {},
                "energy_opportunity_score": 0,
                "extreme_risk_index": 0,
                "event_duration_stats": {},
                "historical_pressure_min": -999
            }

        # Calculate distance from analysis point for each event record
        caribbean_events["distance_to_analysis_point"] = caribbean_events.apply(
            lambda row: geodesic((row["latitude_float"], row["longitude_float"]), (analysis_point_lat, analysis_point_lon)).km,
            axis=1
        )

        # Filter events within the specified radius
        nearby_events = caribbean_events[caribbean_events["distance_to_analysis_point"] <= radius_km].copy()

        if nearby_events.empty:
            return {
                "event_density": 0,
                "event_frequency": {},
                "event_intensity_profile": {},
                "energy_opportunity_score": 0,
                "extreme_risk_index": 0,
                "event_duration_stats": {},
                "historical_pressure_min": -999
            }

        # 1. event_density: density histórica de eventos dentro de un radio (ej. 200 km).
        event_density = nearby_events["storm_id"].nunique()

        # 2. event_frequency: frecuencia anual promedio de cada tipo de evento.
        nearby_events["year"] = pd.to_datetime(nearby_events["date"] + nearby_events["time"], format="%Y%m%d%H%M").dt.year
        total_years = nearby_events["year"].nunique()
        event_frequency = nearby_events.groupby("storm_type")["storm_id"].nunique() / total_years if total_years > 0 else 0
        event_frequency = event_frequency.to_dict()

        # 3. event_intensity_profile: perfil histórico de velocidad del viento.
        event_intensity_profile = nearby_events.groupby("storm_type")["max_sustained_wind_knots"].mean().to_dict()

        # 4. energy_opportunity_score: proporción de eventos con vientos útiles (12–25 m/s).
        # Convert knots to m/s (1 knot = 0.514444 m/s)
        nearby_events["max_sustained_wind_ms"] = nearby_events["max_sustained_wind_knots"] * 0.514444
        useful_wind_events = nearby_events[
            (nearby_events["max_sustained_wind_ms"] >= 12)
            & (nearby_events["max_sustained_wind_ms"] <= 25)
        ]
        energy_opportunity_score = useful_wind_events["storm_id"].nunique() / event_density if event_density > 0 else 0

        # 5. extreme_risk_index: frecuencia de eventos severos (>30 m/s).
        severe_wind_events = nearby_events[nearby_events["max_sustained_wind_ms"] > 30]
        extreme_risk_index = severe_wind_events["storm_id"].nunique() / event_density if event_density > 0 else 0

        # 6. event_duration_stats: duración promedio y variabilidad.
        storm_durations = nearby_events.groupby("storm_id").apply(lambda x:
            (pd.to_datetime(x["date"] + x["time"], format="%Y%m%d%H%M").max() -
             pd.to_datetime(x["date"] + x["time"], format="%Y%m%d%H%M").min()).total_seconds() / 3600
        )
        event_duration_stats = {
            "average_duration_hours": storm_durations.mean() if not storm_durations.empty else 0,
            "std_dev_duration_hours": storm_durations.std() if not storm_durations.empty else 0
        }

        # 7. historical_pressure_min: indicador de afectación ciclónica severa.
        valid_pressures = nearby_events[nearby_events["min_central_pressure_mb"] != -999]["min_central_pressure_mb"]
        historical_pressure_min = valid_pressures.min() if not valid_pressures.empty else -999

        return {
            "event_density": event_density,
            "event_frequency": event_frequency,
            "event_intensity_profile": event_intensity_profile,
            "energy_opportunity_score": energy_opportunity_score,
            "extreme_risk_index": extreme_risk_index,
            "event_duration_stats": event_duration_stats,
            "historical_pressure_min": historical_pressure_min
        }

    def _generate_recommendation(self, metrics):
        # Convert metrics to a DataFrame, ensuring column order matches training data
        # The order of columns in X from ml_module.py was:
        # event_density, avg_wind_speed_hu, avg_wind_speed_ts, energy_opportunity_score, extreme_risk_index, avg_duration_hours, min_pressure
        # Need to map the calculated metrics to the expected input for the model
        # Assuming 'avg_wind_speed_hu' and 'avg_wind_speed_ts' can be derived or are part of event_intensity_profile
        # For now, using placeholder values or deriving from event_intensity_profile if possible

        # Placeholder for avg_wind_speed_hu and avg_wind_speed_ts
        # You would need to define how these are calculated from your hurdat data
        # For now, let's use a simple average from the intensity profile if available
        avg_wind_speed_hu = metrics["event_intensity_profile"].get("HU", 0) # Assuming 'HU' is for Hurricane
        avg_wind_speed_ts = metrics["event_intensity_profile"].get("TS", 0) # Assuming 'TS' is for Tropical Storm

        input_data = {
            'event_density': metrics['event_density'],
            'avg_wind_speed_hu': avg_wind_speed_hu,
            'avg_wind_speed_ts': avg_wind_speed_ts,
            'energy_opportunity_score': metrics['energy_opportunity_score'],
            'extreme_risk_index': metrics['extreme_risk_index'],
            'avg_duration_hours': metrics['event_duration_stats'].get('average_duration_hours', 0),
            'min_pressure': metrics['historical_pressure_min']
        }

        input_df = pd.DataFrame([input_data])

        # Predict the net impact
        predicted_impact = self.model.predict(input_df)[0]

        recommendation = ""
        if predicted_impact == 'positivo':
            recommendation = (
                "**Recomendación: Viabilidad Alta**\n\n" +
                "Este punto geográfico presenta condiciones históricas favorables para proyectos eólicos, " +
                "con una alta puntuación de oportunidad energética y un bajo índice de riesgo extremo. " +
                "Se recomienda proceder con estudios de viabilidad detallados y considerar este sitio como " +
                "prioritario para el desarrollo de energía eólica. " +
                "Monitorear continuamente las condiciones climáticas y realizar análisis de sitio exhaustivos " +
                "para optimizar el diseño del proyecto y la selección de turbinas."
            )
        elif predicted_impact == 'neutral':
            recommendation = (
                "**Recomendación: Viabilidad Moderada**\n\n" +
                "La viabilidad para proyectos eólicos en esta ubicación es moderada. " +
                "Aunque existen oportunidades energéticas, también se han registrado eventos extremos que " +
                "podrían impactar la operación. Se sugiere realizar un análisis de riesgo más profundo, " +
                "considerar tecnologías de turbinas más robustas y diseñar estrategias de mitigación " +
                "para eventos climáticos. La diversificación de la cartera de proyectos podría ser beneficiosa."
            )
        elif predicted_impact == 'negativo':
            recommendation = (
                "**Recomendación: Viabilidad Baja / Riesgo Alto**\n\n" +
                "Este sitio presenta un alto riesgo debido a la frecuencia e intensidad de eventos climáticos extremos, " +
                "lo que reduce significativamente la oportunidad energética. " +
                "No se recomienda la inversión en proyectos eólicos a gran escala en esta ubicación " +
                "sin una reevaluación exhaustiva de los riesgos y la implementación de medidas de protección " +
                "excepcionalmente robustas. Se aconseja explorar ubicaciones alternativas con un perfil de riesgo más favorable."
            )
        else:
            recommendation = "No se pudo generar una recomendación debido a un impacto no reconocido."

        return recommendation, predicted_impact

    def analyze_point(self, latitude, longitude, radius_km=200):
        try:
            metrics = self._calculate_metrics(self.hurdat_df, latitude, longitude, radius_km)
            recommendation, predicted_impact = self._generate_recommendation(metrics)

            return {
                "success": True,
                "latitude": latitude,
                "longitude": longitude,
                "radius_km": radius_km,
                "metrics": metrics,
                "predicted_impact": predicted_impact,
                "recommendation": recommendation
            }
        except Exception as e:
            return {"success": False, "error": str(e)}


