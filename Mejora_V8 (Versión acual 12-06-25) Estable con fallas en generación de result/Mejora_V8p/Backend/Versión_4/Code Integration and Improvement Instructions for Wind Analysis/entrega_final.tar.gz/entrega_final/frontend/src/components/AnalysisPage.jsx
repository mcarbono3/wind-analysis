import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Rectangle, useMapEvents, useMap } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Wind, MapPin, Calendar, Download, TrendingUp, XCircle, ArrowLeft } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import axios from 'axios';
import 'leaflet/dist/leaflet.css';
import { utils as XLSXUtils, writeFile as XLSXWriteFile } from "xlsx";
import jsPDF from 'jspdf';
import 'jspdf-autotable';

// Importar Leaflet y el plugin de heatmap
import L from 'leaflet';
import 'leaflet.heat';

import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

// Solución para el problema del icono predeterminado de Leaflet en Webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

// Configuración de la API
const API_BASE_URL = 'https://wind-analysis.onrender.com/api';

// Funciones helper para acceso seguro a datos
const safeGet = (obj, path, defaultValue = null) => {
  try {
    return path.split('.').reduce((current, key) => current?.[key], obj) ?? defaultValue;
  } catch {
    return defaultValue;
  }
};

const safeNumber = (value, defaultValue = 0) => {
  const num = Number(value);
  return isNaN(num) || !isFinite(num) ? defaultValue : num;
};

const safeArray = (arr, defaultValue = []) => {
  return Array.isArray(arr) && arr.length > 0 ? arr : defaultValue;
};

const formatNumber = (value, decimals = 2, defaultText = 'N/A') => {
  const num = safeNumber(value);
  return num !== 0 || value === 0 ? num.toFixed(decimals) : defaultText;
};

const formatPercentage = (value, decimals = 2, defaultText = 'N/A') => {
  const num = safeNumber(value);
  if (num === 0 && value !== 0) return defaultText;
  return `${(num * 100).toFixed(decimals)}%`;
};

const isValidDate = (date) => {
  return date instanceof Date && !isNaN(date.getTime());
};

const formatDate = (dateString, defaultText = 'Fecha inválida') => {
  try {
    const date = new Date(dateString);
    return isValidDate(date) ? date.toLocaleDateString() : defaultText;
  } catch {
    return defaultText;
  }
};

const formatDateTime = (dateString, defaultText = 'Fecha inválida') => {
  try {
    const date = new Date(dateString);
    return isValidDate(date) ? date.toLocaleString() : defaultText;
  } catch {
    return defaultText;
  }
};

const convertWindSpeed = (value, unit) => {
  const v = safeNumber(value);
  return unit === 'kmh' ? v * 3.6 : v;
};

// Componente para la capa de heatmap del viento promedio
function WindHeatmapLayer({ data }) {
  const map = useMap();
  const heatLayerRef = useRef(null);

  useEffect(() => {
    if (!map || !data?.length) return;

    // Remover capa anterior si existe
    if (heatLayerRef.current) {
      map.removeLayer(heatLayerRef.current);
    }

    // Crear nueva capa
    const newLayer = L.heatLayer(data, {
      radius: 25,
      blur: 15,
      maxZoom: 17,
      max: 12,
      minOpacity: 0.4,
      gradient: {
        0.0: "#0000ff",
        0.25: "#00ffff",
        0.5: "#00ff00",
        0.75: "#ffff00",
        1.0: "#ff0000"
      }
    }).addTo(map);

    heatLayerRef.current = newLayer;

    return () => {
      if (heatLayerRef.current) {
        map.removeLayer(heatLayerRef.current);
      }
    };
  }, [map, data]);

  return null;
}

// Componente principal
const AnalysisPage = () => {
  const [analysisData, setAnalysisData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedCoordinates, setSelectedCoordinates] = useState(null);
  const [manualCoords, setManualCoords] = useState({ lat: '', lng: '' });
  const [windData, setWindData] = useState([]);
  const [heatmapData, setHeatmapData] = useState([]);
  const [selectedRegion, setSelectedRegion] = useState('caribbean');
  const [dateRange, setDateRange] = useState({
    start: '2020-01-01',
    end: '2023-12-31'
  });

  // Función para realizar el análisis de IA
  const performAIAnalysis = async (lat, lng) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.post(`${API_BASE_URL}/ai-diagnosis`, {
        latitude: lat,
        longitude: lng,
        radius_km: 200
      });

      if (response.data.success) {
        setAnalysisData(response.data);
      } else {
        throw new Error(response.data.error || 'Error en el análisis');
      }
    } catch (err) {
      console.error('Error en análisis de IA:', err);
      setError(err.message || 'Error al realizar el análisis');
    } finally {
      setLoading(false);
    }
  };

  // Componente para manejar clicks en el mapa
  function MapClickHandler() {
    useMapEvents({
      click: (e) => {
        const { lat, lng } = e.latlng;
        setSelectedCoordinates({ lat, lng });
        setManualCoords({ lat: lat.toFixed(6), lng: lng.toFixed(6) });
        performAIAnalysis(lat, lng);
      }
    });
    return null;
  }

  // Función para análisis manual
  const handleManualAnalysis = () => {
    const lat = parseFloat(manualCoords.lat);
    const lng = parseFloat(manualCoords.lng);
    
    if (isNaN(lat) || isNaN(lng)) {
      setError('Por favor, ingrese coordenadas válidas');
      return;
    }
    
    setSelectedCoordinates({ lat, lng });
    performAIAnalysis(lat, lng);
  };

  // Función para exportar a Excel
  const exportToExcel = () => {
    if (!analysisData) return;

    const workbook = XLSXUtils.book_new();
    
    // Hoja de resumen
    const summaryData = [
      ['Análisis de Viabilidad Eólica'],
      ['Fecha de análisis', new Date().toLocaleDateString()],
      ['Coordenadas', `${selectedCoordinates?.lat}, ${selectedCoordinates?.lng}`],
      [''],
      ['Diagnóstico Estadístico'],
      ['Velocidad promedio del viento (m/s)', safeGet(analysisData, 'statistical_diagnosis.wind_speed_avg', 'N/A')],
      ['Intensidad de turbulencia', safeGet(analysisData, 'statistical_diagnosis.turbulence_intensity', 'N/A')],
      ['Densidad de potencia (W/m²)', safeGet(analysisData, 'statistical_diagnosis.power_density', 'N/A')],
      ['Clasificación de viabilidad', safeGet(analysisData, 'statistical_diagnosis.viability_classification', 'N/A')],
      [''],
      ['Diagnóstico Climatológico'],
      ['Densidad de eventos', safeGet(analysisData, 'climate_diagnosis.metrics.event_density', 'N/A')],
      ['Puntuación de oportunidad energética', safeGet(analysisData, 'climate_diagnosis.metrics.energy_opportunity_score', 'N/A')],
      ['Índice de riesgo extremo', safeGet(analysisData, 'climate_diagnosis.metrics.extreme_risk_index', 'N/A')],
      ['Impacto predicho', safeGet(analysisData, 'climate_diagnosis.predicted_impact', 'N/A')],
      [''],
      ['Evaluación Consolidada'],
      ['Viabilidad consolidada', safeGet(analysisData, 'consolidated_viability', 'N/A')]
    ];

    const summarySheet = XLSXUtils.aoa_to_sheet(summaryData);
    XLSXUtils.book_append_sheet(workbook, summarySheet, 'Resumen');

    // Guardar archivo
    XLSXWriteFile(workbook, `analisis_eolico_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  // Función para exportar a PDF
  const exportToPDF = () => {
    if (!analysisData) return;

    const doc = new jsPDF();
    
    // Título
    doc.setFontSize(20);
    doc.text('Análisis de Viabilidad Eólica', 20, 20);
    
    // Información básica
    doc.setFontSize(12);
    doc.text(`Fecha: ${new Date().toLocaleDateString()}`, 20, 40);
    doc.text(`Coordenadas: ${selectedCoordinates?.lat}, ${selectedCoordinates?.lng}`, 20, 50);
    
    // Diagnóstico Estadístico
    doc.setFontSize(16);
    doc.text('Diagnóstico Estadístico', 20, 70);
    doc.setFontSize(12);
    doc.text(`Velocidad promedio del viento: ${safeGet(analysisData, 'statistical_diagnosis.wind_speed_avg', 'N/A')} m/s`, 20, 85);
    doc.text(`Intensidad de turbulencia: ${safeGet(analysisData, 'statistical_diagnosis.turbulence_intensity', 'N/A')}`, 20, 95);
    doc.text(`Densidad de potencia: ${safeGet(analysisData, 'statistical_diagnosis.power_density', 'N/A')} W/m²`, 20, 105);
    doc.text(`Clasificación: ${safeGet(analysisData, 'statistical_diagnosis.viability_classification', 'N/A')}`, 20, 115);
    
    // Diagnóstico Climatológico
    doc.setFontSize(16);
    doc.text('Diagnóstico Climatológico', 20, 135);
    doc.setFontSize(12);
    doc.text(`Densidad de eventos: ${safeGet(analysisData, 'climate_diagnosis.metrics.event_density', 'N/A')}`, 20, 150);
    doc.text(`Oportunidad energética: ${safeGet(analysisData, 'climate_diagnosis.metrics.energy_opportunity_score', 'N/A')}`, 20, 160);
    doc.text(`Riesgo extremo: ${safeGet(analysisData, 'climate_diagnosis.metrics.extreme_risk_index', 'N/A')}`, 20, 170);
    doc.text(`Impacto predicho: ${safeGet(analysisData, 'climate_diagnosis.predicted_impact', 'N/A')}`, 20, 180);
    
    // Evaluación Consolidada
    doc.setFontSize(16);
    doc.text('Evaluación Consolidada', 20, 200);
    doc.setFontSize(12);
    doc.text(`Viabilidad: ${safeGet(analysisData, 'consolidated_viability', 'N/A')}`, 20, 215);
    
    // Recomendaciones (nueva página si es necesario)
    if (safeGet(analysisData, 'combined_recommendations')) {
      doc.addPage();
      doc.setFontSize(16);
      doc.text('Recomendaciones', 20, 20);
      doc.setFontSize(10);
      const recommendations = safeGet(analysisData, 'combined_recommendations', '').split('\n');
      let yPosition = 35;
      recommendations.forEach(line => {
        if (yPosition > 280) {
          doc.addPage();
          yPosition = 20;
        }
        doc.text(line, 20, yPosition);
        yPosition += 7;
      });
    }
    
    doc.save(`analisis_eolico_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  // Función para obtener el color del badge según la viabilidad
  const getViabilityColor = (viability) => {
    switch (viability?.toLowerCase()) {
      case 'alta':
      case 'alto':
        return 'bg-green-100 text-green-800';
      case 'moderada':
      case 'moderado':
        return 'bg-yellow-100 text-yellow-800';
      case 'baja':
      case 'bajo':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Análisis de Viabilidad Eólica
          </h1>
          <p className="text-gray-600">
            Sistema experto para evaluar la viabilidad de proyectos eólicos en el Caribe colombiano
          </p>
        </div>

        {/* Controles de entrada */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Selección de Ubicación
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="lat">Latitud</Label>
                <Input
                  id="lat"
                  type="number"
                  step="0.000001"
                  value={manualCoords.lat}
                  onChange={(e) => setManualCoords(prev => ({ ...prev, lat: e.target.value }))}
                  placeholder="Ej: 10.9685"
                />
              </div>
              <div>
                <Label htmlFor="lng">Longitud</Label>
                <Input
                  id="lng"
                  type="number"
                  step="0.000001"
                  value={manualCoords.lng}
                  onChange={(e) => setManualCoords(prev => ({ ...prev, lng: e.target.value }))}
                  placeholder="Ej: -74.7813"
                />
              </div>
              <div className="flex items-end">
                <Button 
                  onClick={handleManualAnalysis}
                  disabled={loading}
                  className="w-full"
                >
                  {loading ? 'Analizando...' : 'Analizar Ubicación'}
                </Button>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-2">
              También puede hacer clic en el mapa para seleccionar una ubicación
            </p>
          </CardContent>
        </Card>

        {/* Mapa */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Mapa Interactivo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-96 rounded-lg overflow-hidden">
              <MapContainer
                center={[11.5, -74.5]}
                zoom={7}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                <MapClickHandler />
                {selectedCoordinates && (
                  <Rectangle
                    bounds={[
                      [selectedCoordinates.lat - 0.01, selectedCoordinates.lng - 0.01],
                      [selectedCoordinates.lat + 0.01, selectedCoordinates.lng + 0.01]
                    ]}
                    pathOptions={{ color: 'red', weight: 2 }}
                  />
                )}
                <WindHeatmapLayer data={heatmapData} />
              </MapContainer>
            </div>
          </CardContent>
        </Card>

        {/* Mostrar errores */}
        {error && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <XCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Resultados del análisis */}
        {analysisData && (
          <div className="space-y-6">
            {/* Resumen ejecutivo */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Resumen Ejecutivo
                  </span>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={exportToExcel}>
                      <Download className="h-4 w-4 mr-2" />
                      Excel
                    </Button>
                    <Button variant="outline" size="sm" onClick={exportToPDF}>
                      <Download className="h-4 w-4 mr-2" />
                      PDF
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600 mb-1">
                      {safeGet(analysisData, 'statistical_diagnosis.viability_classification', 'N/A')}
                    </div>
                    <div className="text-sm text-gray-600">Diagnóstico Estadístico</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600 mb-1">
                      {safeGet(analysisData, 'climate_diagnosis.predicted_impact', 'N/A')}
                    </div>
                    <div className="text-sm text-gray-600">Impacto Climatológico</div>
                  </div>
                  <div className="text-center">
                    <Badge className={getViabilityColor(safeGet(analysisData, 'consolidated_viability'))}>
                      {safeGet(analysisData, 'consolidated_viability', 'N/A')}
                    </Badge>
                    <div className="text-sm text-gray-600 mt-1">Viabilidad Consolidada</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tabs con análisis detallado */}
            <Tabs defaultValue="statistical" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="statistical">Análisis Estadístico</TabsTrigger>
                <TabsTrigger value="climate">Análisis Climatológico</TabsTrigger>
                <TabsTrigger value="recommendations">Recomendaciones</TabsTrigger>
              </TabsList>

              <TabsContent value="statistical" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Métricas Estadísticas del Viento</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">
                          {formatNumber(safeGet(analysisData, 'statistical_diagnosis.wind_speed_avg'), 1)}
                        </div>
                        <div className="text-sm text-gray-600">Velocidad promedio (m/s)</div>
                      </div>
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">
                          {formatNumber(safeGet(analysisData, 'statistical_diagnosis.turbulence_intensity'), 3)}
                        </div>
                        <div className="text-sm text-gray-600">Intensidad de turbulencia</div>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">
                          {formatNumber(safeGet(analysisData, 'statistical_diagnosis.power_density'), 0)}
                        </div>
                        <div className="text-sm text-gray-600">Densidad de potencia (W/m²)</div>
                      </div>
                      <div className="text-center p-4 bg-orange-50 rounded-lg">
                        <Badge className={getViabilityColor(safeGet(analysisData, 'statistical_diagnosis.viability_classification'))}>
                          {safeGet(analysisData, 'statistical_diagnosis.viability_classification', 'N/A')}
                        </Badge>
                        <div className="text-sm text-gray-600 mt-1">Clasificación</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="climate" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Análisis Climatológico</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">
                          {formatNumber(safeGet(analysisData, 'climate_diagnosis.metrics.event_density'), 0)}
                        </div>
                        <div className="text-sm text-gray-600">Densidad de eventos</div>
                      </div>
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">
                          {formatPercentage(safeGet(analysisData, 'climate_diagnosis.metrics.energy_opportunity_score'))}
                        </div>
                        <div className="text-sm text-gray-600">Oportunidad energética</div>
                      </div>
                      <div className="text-center p-4 bg-red-50 rounded-lg">
                        <div className="text-2xl font-bold text-red-600">
                          {formatPercentage(safeGet(analysisData, 'climate_diagnosis.metrics.extreme_risk_index'))}
                        </div>
                        <div className="text-sm text-gray-600">Riesgo extremo</div>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">
                          {formatNumber(safeGet(analysisData, 'climate_diagnosis.metrics.historical_pressure_min'), 0)}
                        </div>
                        <div className="text-sm text-gray-600">Presión mínima (mb)</div>
                      </div>
                    </div>

                    {/* Estadísticas de duración */}
                    {safeGet(analysisData, 'climate_diagnosis.metrics.event_duration_stats') && (
                      <div className="mt-4">
                        <h4 className="text-lg font-semibold mb-2">Estadísticas de Duración de Eventos</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center p-4 bg-gray-50 rounded-lg">
                            <div className="text-xl font-bold text-gray-700">
                              {formatNumber(safeGet(analysisData, 'climate_diagnosis.metrics.event_duration_stats.average_duration_hours'), 1)}
                            </div>
                            <div className="text-sm text-gray-600">Duración promedio (horas)</div>
                          </div>
                          <div className="text-center p-4 bg-gray-50 rounded-lg">
                            <div className="text-xl font-bold text-gray-700">
                              {formatNumber(safeGet(analysisData, 'climate_diagnosis.metrics.event_duration_stats.std_dev_duration_hours'), 1)}
                            </div>
                            <div className="text-sm text-gray-600">Desviación estándar (horas)</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="recommendations" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Recomendaciones Técnicas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Recomendación climatológica */}
                      {safeGet(analysisData, 'climate_diagnosis.recommendation') && (
                        <div className="p-4 bg-blue-50 rounded-lg">
                          <h4 className="font-semibold text-blue-800 mb-2">Análisis Climatológico</h4>
                          <div className="text-sm text-blue-700 whitespace-pre-line">
                            {safeGet(analysisData, 'climate_diagnosis.recommendation')}
                          </div>
                        </div>
                      )}

                      {/* Recomendaciones combinadas */}
                      {safeGet(analysisData, 'combined_recommendations') && (
                        <div className="p-4 bg-green-50 rounded-lg">
                          <h4 className="font-semibold text-green-800 mb-2">Recomendaciones Consolidadas</h4>
                          <div className="text-sm text-green-700 whitespace-pre-line">
                            {safeGet(analysisData, 'combined_recommendations')}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Explicaciones detalladas */}
                <Card>
                  <CardHeader>
                    <CardTitle>Explicaciones Detalladas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Módulo de análisis climatológico */}
                      {safeGet(analysisData, 'detailed_explanations.climate_analysis_module') && (
                        <div className="p-4 border rounded-lg">
                          <h4 className="font-semibold mb-2">Módulo de Análisis Climatológico</h4>
                          <p className="text-sm text-gray-600 mb-2">
                            {safeGet(analysisData, 'detailed_explanations.climate_analysis_module.description')}
                          </p>
                          <div className="text-sm">
                            <strong>Impacto predicho:</strong> {safeGet(analysisData, 'detailed_explanations.climate_analysis_module.predicted_impact')}
                          </div>
                        </div>
                      )}

                      {/* Diagnóstico estadístico */}
                      {safeGet(analysisData, 'detailed_explanations.statistical_diagnosis') && (
                        <div className="p-4 border rounded-lg">
                          <h4 className="font-semibold mb-2">Diagnóstico Estadístico</h4>
                          <p className="text-sm text-gray-600">
                            {safeGet(analysisData, 'detailed_explanations.statistical_diagnosis.description')}
                          </p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        )}

        {/* Mensaje cuando no hay datos */}
        {!analysisData && !loading && (
          <Card>
            <CardContent className="text-center py-12">
              <Wind className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Seleccione una ubicación para comenzar
              </h3>
              <p className="text-gray-600">
                Haga clic en el mapa o ingrese coordenadas manualmente para realizar un análisis de viabilidad eólica
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AnalysisPage;

